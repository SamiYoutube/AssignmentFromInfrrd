﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CategoryAmtCalc.Models;

namespace CategoryAmtCalc.Controllers
{
    public class CategoryController : Controller
    {
        private NewAssignmentEntities db = new NewAssignmentEntities();
        List<SelectListItem> ddlYears = new List<SelectListItem>();
        // GET: Category
        public ActionResult Index()
        {
            var categoryview = db.CategoryDetails.GroupBy(c => c.Category).Select(g => new { Category = g.Key, before2018 = g.Sum(c => c.Before2018), In2018 = g.Sum(c => c.Year2018), In2019 = g.Sum(c => c.Year2019), In2020 = g.Sum(c => c.Year2020), after2020 = g.Sum(c => c.After2020) }).ToList();

            //return View(db.CategoryTbls.ToList());
            return View(db.CategoryDetails.ToList());
        }
        


       
        // GET: Category/Create
        public ActionResult Create(int id=0)
        {
            return View();
        }

        // POST: Category/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Category,Amount,Date")] CategoryTbl categoryTbl)
        {
            //if (ModelState.IsValid)
            //{
            //    db.CategoryTbls.Add(categoryTbl);
            //    db.SaveChanges();
            //    return RedirectToAction("CategoryInfo");
            //}

            //return View(categoryTbl);
            try
            {
                if (categoryTbl.ID <= 0)
                {
                    db.CategoryTbls.Add(categoryTbl);
                }
                else
                {
                    db.Entry(categoryTbl).State = EntityState.Modified;
                }
                db.SaveChanges();
                ViewBag.Success = "You successfully saved.";
                ModelState.Clear();

                //return RedirectToAction("Index");
                return View();
            }
            catch (Exception)
            {
                return Json(new { success = true, message = "There was a problem with database" }, JsonRequestBehavior.AllowGet);
            }
        }

        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
